# Simple counter-app for demonstrating Docker Compose
Simple flask app that counts web site visits and stores in a default Redis backend.

**References:**
- Getting Started with Docker video training course

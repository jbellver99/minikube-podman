# Swarm stack

Python flask app:
- stores counter in redis
- returns count and hostname of contriner servicing request

